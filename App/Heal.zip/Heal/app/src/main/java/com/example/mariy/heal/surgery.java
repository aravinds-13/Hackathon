package com.example.mariy.heal;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.SearchView;
import android.widget.Toast;

public class surgery extends AppCompatActivity implements SearchView.OnQueryTextListener{
    ListView l1;
    SearchView s1;
    ArrayAdapter<String>adapter;
    String[]data ={"Pediatric surgery","Orthopedic surgery","Neurosurgery","Heart Surgery","Eye Surgery","Bariatric surgery"};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_surgery);

        l1=(ListView)findViewById(R.id.list);
        s1=(SearchView)findViewById(R.id.search);
        adapter = new ArrayAdapter<String>(this,android.R.layout.simple_list_item_1,data);
        l1.setAdapter(adapter);
        s1.setOnQueryTextListener(this);


        l1.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> data, View view, int i, long l) {
                int pos = data.getPositionForView(view);

                Intent intent = new Intent(surgery.this,location.class);
                if(pos == 0){
                    intent.putExtra("flag","0");
                    startActivity(intent);
                }
                else{
                    intent.putExtra("flag","1");
                    startActivity(intent);
                }

            }
        });
    }
    public boolean onQueryTextSubmit(String query){
        return false;
    }
    public boolean onQueryTextChange(String newText){
        String text = newText;
        adapter.getFilter().filter(newText);
        return false;
    }
}
