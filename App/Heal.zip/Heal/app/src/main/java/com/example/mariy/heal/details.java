package com.example.mariy.heal;

import android.content.Intent;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

public class details extends AppCompatActivity {
    Button b1;
    TextView t1,t2;
    public String test;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_details);

        Bundle val = getIntent().getExtras();
        test=val.getString("hdetail");

        new AlertDialog.Builder(this).setMessage(test).show();

        b1 = (Button)findViewById(R.id.btnref);
        t1 = (TextView)findViewById(R.id.title);
        t2 = (TextView)findViewById(R.id.details);



        if (test.equals("man")){
            t1.setText("Bannerghatta Hospital");
            t2.setText("Lorem Ipsium dolor sit amet, consectetur adipiscing elit. In blandit sollicitudin nulla. Nullam scelerisque tortor et eros finibus, eget facilisis augue cursus. Pellentesque in blandit turpis, eget molestie est. Mauris placerat orci ullamcorper, dignissim felis eu, pretium nisi. Nullam venenatis odio purus, et ultricies diam dapibus et. Sed ultricies suscipit nisi et placerat. Sed mollis convallis mi et iaculis. Morbi placerat id tellus at tincidunt. Pellentesque sit amet auctor arcu. Phasellus eget tortor pharetra, porttitor mauris facilisis, finibus metus. Cras imperdiet dictum felis et gravida. Aliquam eget lorem ac nibh pellentesque congue. Nunc ultricies laoreet mattis. Integer quis laoreet tortor.");
        }

    }
}
