package com.example.mariy.heal;

import android.content.Intent;
import android.support.v4.app.FragmentActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import com.google.android.gms.maps.CameraUpdate;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;

public class location extends FragmentActivity implements OnMapReadyCallback {

    private GoogleMap mMap,mMap1,mMap2,mMap3,mMap4,mMap5;
    public String flag;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_location);

        Bundle val = getIntent().getExtras();
        flag = (val.getString("flag"));

        // Obtain the SupportMapFragment and get notified when the map is ready to be used.
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);
    }


    /**
     * Manipulates the map once available.
     * This callback is triggered when the map is ready to be used.
     * This is where we can add markers or lines, add listeners or move the camera. In this case,
     * we just add a marker near Sydney, Australia.
     * If Google Play services is not installed on the device, the user will be prompted to install
     * it inside the SupportMapFragment. This method will only be triggered once the user has
     * installed Google Play services and returned to the app.
     */
    @Override
    public void onMapReady(GoogleMap googleMap) {
        //mMap = googleMap;

        if(flag.equals("0")){
            mMap2 = googleMap;
            mMap4 = googleMap;

            LatLng Bannerghatta = new LatLng(12.8963227,77.5959768);
            mMap2.addMarker(new MarkerOptions().position(Bannerghatta).title("Bannerghatta")).setVisible(true);
            mMap2.animateCamera(CameraUpdateFactory.newLatLngZoom(Bannerghatta,18),5000,null);

            mMap2.setOnInfoWindowClickListener(new GoogleMap.OnInfoWindowClickListener() {
                @Override
                public void onInfoWindowClick(Marker marker) {
                    Intent i = new Intent(location.this,details.class);
                    i.putExtra("hdetail","ban");
                    startActivity(i);
                }
            });

            LatLng manipal = new LatLng(12.9346627,77.5408843);
            mMap4.addMarker(new MarkerOptions().position(manipal).title("Manipals Hospital")).setVisible(true);
            mMap4.animateCamera(CameraUpdateFactory.newLatLngZoom(manipal,18),5000,null);

            mMap4.setOnInfoWindowClickListener(new GoogleMap.OnInfoWindowClickListener() {
                @Override
                public void onInfoWindowClick(Marker marker) {
                    Intent i = new Intent(location.this,details.class);
                    i.putExtra("hdetail","man");
                    startActivity(i);
                }
            });

        }
        else{
            mMap1=googleMap;
            mMap = googleMap;
            mMap3=googleMap;
            LatLng johns = new LatLng(12.9305109,77.6164582);
            mMap1.addMarker(new MarkerOptions().position(johns).title("St.Johns"));
            mMap1.animateCamera(CameraUpdateFactory.newLatLngZoom(johns,18),5000,null);

            mMap1.setOnInfoWindowClickListener(new GoogleMap.OnInfoWindowClickListener() {
                @Override
                public void onInfoWindowClick(Marker marker) {
                    Intent i = new Intent(location.this,details.class);
                    i.putExtra("hdetail","john");
                    startActivity(i);
                }
            });

            //mMap.moveCamera(CameraUpdateFactory.newLatLng(johns));

            LatLng medcity  = new LatLng(10.0434923,76.2758308);
            mMap.addMarker(new MarkerOptions().position(medcity).title("Aster Medicity"));
            mMap.animateCamera(CameraUpdateFactory.newLatLngZoom(medcity,18),5000,null);
            mMap4.setOnInfoWindowClickListener(new GoogleMap.OnInfoWindowClickListener() {
                @Override
                public void onInfoWindowClick(Marker marker) {
                    Intent i = new Intent(location.this,details.class);
                    i.putExtra("hdetail","medc");
                    startActivity(i);
                }
            });
            //mMap.moveCamera(CameraUpdateFactory.newLatLng(medcity));

            LatLng kims = new LatLng(8.5137118,76.9071564);
            mMap3.addMarker(new MarkerOptions().position(kims).title("KIMS"));
            mMap3.animateCamera(CameraUpdateFactory.newLatLngZoom(kims,18),5000,null);

            mMap4.setOnInfoWindowClickListener(new GoogleMap.OnInfoWindowClickListener() {
                @Override
                public void onInfoWindowClick(Marker marker) {
                    Intent i = new Intent(location.this,details.class);
                    i.putExtra("hdetail","kim");
                    startActivity(i);
                }
            });
            //mMap.moveCamera(CameraUpdateFactory.newLatLng(kims));

        }


        // Add a marker in Sydney and move the camera
        /*LatLng Bannerghatta = new LatLng(12.8963227,77.5959768);
        mMap.addMarker(new MarkerOptions().position(Bannerghatta).title("Bannerghatta"));
        mMap.animateCamera(CameraUpdateFactory.newLatLngZoom(Bannerghatta,18),5000,null);
        //mMap.moveCamera(CameraUpdateFactory.newLatLng(Bannerghatta));



        LatLng manipal = new LatLng(12.9346627,77.5408843);
        mMap.addMarker(new MarkerOptions().position(manipal).title("Manipals Hospital"));
        mMap.animateCamera(CameraUpdateFactory.newLatLngZoom(manipal,18),5000,null);

        //mMap.moveCamera(CameraUpdateFactory.newLatLng(manipal));
       mMap.setOnInfoWindowClickListener(new GoogleMap.OnInfoWindowClickListener() {
           @Override
           public void onInfoWindowClick(Marker marker) {
               Intent i = new Intent(location.this,details.class);
               startActivity(i);
           }
       });*/

    }
}
